#include "configUtil.h"

bool metaRead(FILE *fh2, int recCount, opcode *meta);
void metaPrint(opcode *metaData);
bool metaCheck(opcode *metaData);
