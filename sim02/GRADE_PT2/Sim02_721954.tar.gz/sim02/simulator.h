#ifndef SIMULATOR_H
#define SIMULATOR_H

//#include "datatypes.h"
#include "stringUtility.h"
#include "configops.h"
#include "metadataops.h"

void runSim( ConfigDataType *configPtr, OpCodeType *metaDataMstrPtr);

#endif // SIMULATOR_H
