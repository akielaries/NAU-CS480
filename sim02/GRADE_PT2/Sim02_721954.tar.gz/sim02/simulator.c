#include "simulator.h"

void runSim( ConfigDataType *configPtr, OpCodeType *metaDataMstrPtr)
   {

   }
