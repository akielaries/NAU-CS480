#ifndef SIM_H
#define SIM_H

#include "types.h"
#include <stdio.h>

void runSim(ConfigDataType *config_dataptr, OpCodeType *meta_data_ptr);

#endif
