#include "sim.h"
/**
 * Driver code for running the simulator
 */

void runSim(ConfigDataType *config_dataptr, OpCodeType *meta_data_ptr)
{
    printf("runSim called here.\n");
}
