#ifndef SIMULATOR_H
#define SIMULATOR_H

// Header files
#include "datatypes.h"

// Function declaration
void runSim(ConfigDataType *configPtr, OpCodeType *metaDAtaMstrPtr);

#endif // SIMULATOR_H
